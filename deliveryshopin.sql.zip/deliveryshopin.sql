-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-07-2020 a las 22:42:17
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `deliveryshopin`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `codCli` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellido` varchar(30) NOT NULL,
  `correo` varchar(30) NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `pas` varchar(30) NOT NULL,
  `dire_detalle` longtext NOT NULL,
  `estado` varchar(40) NOT NULL,
  `time_login` varchar(40) NOT NULL,
  `time_logout` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`codCli`, `nombre`, `apellido`, `correo`, `direccion`, `pas`, `dire_detalle`, `estado`, `time_login`, `time_logout`) VALUES
(2, 'Elmer ', 'Tugri ', 'elmermontero15@hotmail.com', 'California;Puerto Armuelles', '1234567', 'Calle Principal, Casa Verde agua', 'desconectado', '2020-Jul-Sun 12:22:53', '2020-Jul-Sun 12:26:52');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detallepedido`
--

CREATE TABLE `detallepedido` (
  `numpedido` int(11) NOT NULL,
  `codpro` int(11) NOT NULL,
  `can` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresa`
--

CREATE TABLE `empresa` (
  `cod_empresa` int(11) NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `ubicacion` varchar(400) NOT NULL,
  `cuenta` varchar(40) NOT NULL,
  `pas` varchar(200) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `telefono` varchar(30) NOT NULL,
  `estado` varchar(40) NOT NULL,
  `time_login` varchar(40) NOT NULL,
  `time_logout` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `empresa`
--

INSERT INTO `empresa` (`cod_empresa`, `nombre`, `ubicacion`, `cuenta`, `pas`, `correo`, `telefono`, `estado`, `time_login`, `time_logout`) VALUES
(1, 'Panyao', 'Centro de Puerto Armuelles alado de la p', '48946549846549', '123', 'anatugrimontero@gmail.com', '6648756', 'desconectado', '2020-Jul-Sun 12:38:09', '2020-Jul-Sun 12:39:59'),
(2, 'Romero', 'Calle Principal, Después de la entra a M', '14949889148', '123', 'correo@hotmail.com', '494849', 'desconectado', '2020-Jul-Fri 3:58:03', '2020-Jul-Fri 4:00:40'),
(3, 'Rey', 'desconocido', '6498119898', '12345', 'holamundo@gmail.es', '6248575', '', '', ''),
(4, 'Puerto Armuelles', 'centro de Puerto', '64981989', '12345', 'fuerza@gmail.com', '63257855', '', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

CREATE TABLE `factura` (
  `cod_factura` int(11) NOT NULL,
  `numPedido` varchar(100) NOT NULL,
  `fecha` datetime NOT NULL,
  `monto` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedido`
--

CREATE TABLE `pedido` (
  `numPedido` int(11) NOT NULL,
  `codCli` varchar(100) NOT NULL,
  `fecha` date NOT NULL,
  `fech_entreg` datetime NOT NULL,
  `direccion` point NOT NULL,
  `detalle_direccion` longtext NOT NULL,
  `cod_factura` varchar(100) NOT NULL,
  `cod_empresa` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `codpro` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `precio` decimal(8,2) NOT NULL,
  `stock` varchar(40) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `detalle` varchar(1000) NOT NULL,
  `Cod_super` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`codpro`, `nombre`, `precio`, `stock`, `cantidad`, `detalle`, `Cod_super`) VALUES
(10, 'Aceite', '5.10', 'Aceites', 40, 'aceite oleocal de 1Lt.', '1'),
(11, 'Arroz Premier', '10.00', 'Granos', 20, 'Arroz de Primera', '2'),
(12, 'Colgate', '2.00', 'Aseo Personal', 40, 'Pasta de Diente colgate, tamaño: grande', '1'),
(13, 'Pack x12 Leche Chiricana', '10.00', 'Lacteos', 20, 'Un Paquete de 12 leches en uno a un precio modico', '3'),
(14, 'Lechuga', '2.00', 'Vegetales', 50, 'Cada paquete tiene 2 libras', '2'),
(16, 'Frijoles Chiricanos Rojos', '3.30', 'Granos', 30, 'Frijoles chiricanos rojos de 1Lb.', '1');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`codCli`);

--
-- Indices de la tabla `detallepedido`
--
ALTER TABLE `detallepedido`
  ADD KEY `numpedido` (`numpedido`),
  ADD KEY `codpro` (`codpro`);

--
-- Indices de la tabla `empresa`
--
ALTER TABLE `empresa`
  ADD PRIMARY KEY (`cod_empresa`);

--
-- Indices de la tabla `factura`
--
ALTER TABLE `factura`
  ADD PRIMARY KEY (`cod_factura`);

--
-- Indices de la tabla `pedido`
--
ALTER TABLE `pedido`
  ADD PRIMARY KEY (`numPedido`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`codpro`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `codCli` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `empresa`
--
ALTER TABLE `empresa`
  MODIFY `cod_empresa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `factura`
--
ALTER TABLE `factura`
  MODIFY `cod_factura` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pedido`
--
ALTER TABLE `pedido`
  MODIFY `numPedido` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `codpro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `detallepedido`
--
ALTER TABLE `detallepedido`
  ADD CONSTRAINT `detalepedio_cod1` FOREIGN KEY (`numpedido`) REFERENCES `pedido` (`numPedido`) ON UPDATE CASCADE,
  ADD CONSTRAINT `detallepedido_ibfk_1` FOREIGN KEY (`codpro`) REFERENCES `productos` (`codpro`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
